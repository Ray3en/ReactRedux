import React from 'react';
import ReactDOM from 'react-dom/client';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import App from './App';

const defaultState = {
    count: 0
}

// action = {type: 'INCR', payload: 1}

const reducer = (state = defaultState, action) => {
    switch (action.type) {
        case 'INCR':
            return {...state, count: state.count + action.payload}
        case 'DECR':
            return {...state, count: state.count - action.payload}
        default:
            return state
    }
}

const store = createStore(reducer)



const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
    <Provider store = {store}>
    <App/>
    </Provider>
);