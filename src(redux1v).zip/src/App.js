import { useSelector, useDispatch } from "react-redux";


function App() {

  const disptach = useDispatch()
  const count = useSelector(state => state.count)

  return (
    <div >
      {count}
      <div>
        <button onClick={()=> disptach({type: 'INCR', payload: 1})}>Добавить</button>
        <button onClick={()=> disptach({type: 'DECR', payload: 1})}> Убавить</button>
      </div>
    </div>
  );
}

export default App;
